I created this tool rental application using Hibernate and mysql for the database.
I decided to do it this way because ideally there would be a database for a large number of inventory,
so creating a database and using Hibernate to map Java classes with the schema would make sense to update
all the inventory as tools are being rented.
I was not able to finish the implementation but I got the main idea of creating the database with the schemas
and using Hibernate to create the corresponding Java classes.

I referenced code from https://github.com/daliasheasha/HibernateApp/blob/master/src/main/java/Main.java
since I was following a tutorial on how to use Hibernate and needed help with the set up

The input values are hardcoded in the main class since I was not able to complete unit testing -
To test it just change those values for the tool code, amount of rental days, etc.