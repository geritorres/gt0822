import entity.ToolEntity;

import java.time.LocalDate;
import java.util.*;
import javax.persistence.*;

public class Main {
    public static void main(String[] args) {
        EntityManagerFactory managerFactory = Persistence.createEntityManagerFactory("default");
        EntityManager manager = managerFactory.createEntityManager();
        EntityTransaction transaction = manager.getTransaction();

        try {
            transaction.begin();

            Query result = manager.createNativeQuery("SELECT t.toolCode, t.toolType, t.brand, c.daily  FROM Tool t JOIN Charge c ON t.toolType = c.toolType WHERE t.toolCode=:code ");
            result.setParameter("code", "CHNS");
            //System.out.println(result.getSingleResult().toString());
            List<Object[]> data = result.getResultList();
            for (Object[] a : data){
                System.out.println(a[0] + " " + a[1] + " " + a[2] + " " + a[3]);
                int value = checkout(a[0].toString(), 3, 20,  LocalDate.of(2022, 8, 20), a[1].toString(), a[2].toString(), Double.parseDouble(a[3].toString()));
            }



            transaction.commit();
        } finally {
            if(transaction.isActive()){
                transaction.rollback();
            }
            manager.close();
            managerFactory.close();
        }
    }

    //method that generates the rental application
    //returns 0 if the inputs are invalid and prints out error message
    //returns 1 if the rental application is successful
    public static int checkout(String code, int rentalDayCount, int discount, LocalDate date, String type, String brand, double dailyCharge){
        if (rentalDayCount < 1) {
            System.out.println("Number of rentals days must be more than 1");
            return 0;
        }
        if (discount <= 0 || discount >= 100) {
            System.out.println("Discount not valid - must be between 1-99%");
            return 0;
        }

        System.out.println("Tool Rental Application Complete - Find details below: \n" +
                "Tool Code: " +  code + "\n" +
                "Tool Type: " +  type + "\n" +
                "Tool Brand: " + brand + "\n" +
                "Rental Days: " + rentalDayCount + "\n" +
                "Checkout Date: " + date + "\n" +
                "Due Date: " + dueDate(date, rentalDayCount) + "\n" +
                "Daily Rental Charge: " + dailyCharge);

        return 1;
    }

    //method to calculate the due date of the tool
    public static LocalDate dueDate(LocalDate checkoutDate, int dayCount){
        LocalDate due = checkoutDate.plusDays(dayCount);
        return due;
    }
}
