package entity;

/*
Tool Entity Class that was generated from the persistence mapping to match the database schema
 */
import javax.persistence.*;

@Entity
@Table(name = "Tool", schema = "gtorres1")
public class ToolEntity {
    @Basic
    @Column(name = "toolCode", nullable = false, length = 45)
    private String toolCode;
    @Basic
    @Column(name = "toolType", nullable = false, length = 45)
    private String toolType;
    @Basic
    @Column(name = "brand", nullable = false, length = 45)
    private String brand;
    @Id
    private Long id;

    public String getToolCode() {
        return toolCode;
    }

    public void setToolCode(String toolCode) {
        this.toolCode = toolCode;
    }

    public String getToolType() {
        return toolType;
    }

    public void setToolType(String toolType) {
        this.toolType = toolType;
    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        ToolEntity that = (ToolEntity) o;

        if (toolCode != null ? !toolCode.equals(that.toolCode) : that.toolCode != null) return false;
        if (toolType != null ? !toolType.equals(that.toolType) : that.toolType != null) return false;
        if (brand != null ? !brand.equals(that.brand) : that.brand != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = toolCode != null ? toolCode.hashCode() : 0;
        result = 31 * result + (toolType != null ? toolType.hashCode() : 0);
        result = 31 * result + (brand != null ? brand.hashCode() : 0);
        return result;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getId() {
        return id;
    }

    @Override
    public String toString() {
        return "ToolEntity{" +
                "toolCode='" + toolCode + '\'' +
                ", toolType='" + toolType + '\'' +
                ", brand='" + brand + '\'' +
                ", id=" + id +
                '}';
    }
}
