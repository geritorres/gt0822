package entity;

/*
Charge Entity Class that was generated from the persistence mapping to match the database schema
 */
import javax.persistence.*;

@Entity
@Table(name = "Charge", schema = "gtorres1")
//@Table(name = "Charge", schema = "gtorres1", catalog = "")
public class ChargeEntity {
    @Basic
    @Column(name = "toolType", nullable = false, length = 45)
    private String toolType;
    @Basic
    @Column(name = "daily", nullable = false, precision = 0)
    private double daily;
    @Basic
    @Column(name = "weekday", nullable = false)
    private byte weekday;
    @Basic
    @Column(name = "weekend", nullable = false)
    private byte weekend;
    @Basic
    @Column(name = "holiday", nullable = false)
    private byte holiday;
    @Id
    private Long id;

    public String getToolType() {
        return toolType;
    }

    public void setToolType(String toolType) {
        this.toolType = toolType;
    }

    public double getDaily() {
        return daily;
    }

    public void setDaily(double daily) {
        this.daily = daily;
    }

    public byte getWeekday() {
        return weekday;
    }

    public void setWeekday(byte weekday) {
        this.weekday = weekday;
    }

    public byte getWeekend() {
        return weekend;
    }

    public void setWeekend(byte weekend) {
        this.weekend = weekend;
    }

    public byte getHoliday() {
        return holiday;
    }

    public void setHoliday(byte holiday) {
        this.holiday = holiday;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        ChargeEntity that = (ChargeEntity) o;

        if (Double.compare(that.daily, daily) != 0) return false;
        if (weekday != that.weekday) return false;
        if (weekend != that.weekend) return false;
        if (holiday != that.holiday) return false;
        if (toolType != null ? !toolType.equals(that.toolType) : that.toolType != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result;
        long temp;
        result = toolType != null ? toolType.hashCode() : 0;
        temp = Double.doubleToLongBits(daily);
        result = 31 * result + (int) (temp ^ (temp >>> 32));
        result = 31 * result + (int) weekday;
        result = 31 * result + (int) weekend;
        result = 31 * result + (int) holiday;
        return result;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getId() {
        return id;
    }

    @Override
    public String toString() {
        return "ChargeEntity{" +
                "toolType='" + toolType + '\'' +
                ", daily=" + daily +
                ", weekday=" + weekday +
                ", weekend=" + weekend +
                ", holiday=" + holiday +
                ", id=" + id +
                '}';
    }
}
