public class Main {
    public static void main(String[] args) {

        Tool tool1 = new Tool("CNHS", "Chainsaw", "Stihl");
        Tool tool2 = new Tool("LADW", "Ladder", "Werner");
        Tool tool3 = new Tool("JAKD", "Jackhammer", "DeWalt");
        Tool tool4 = new Tool("JAKR", "Jackhammer", "Ridgid");

        Charge chainsaw = new Charge(tool1, 1.49, true, false, true);
        Charge ladder = new Charge(tool2, 1.99, true, true, false);
        Charge jackhammerD = new Charge(tool3, 2.99, true, false, false);
        Charge jackhammerR = new Charge(tool4, 2.99, true, false, false);


        System.out.println(ladder.getTool().getType());
        System.out.println(ladder.isWeekday());
        System.out.println(chainsaw.getTool().getType());
        System.out.println(jackhammerD.getTool().getType());
        System.out.println(jackhammerR.getTool().getType());
//        public static void createRentalApplication() {
//
//        }



    }
}