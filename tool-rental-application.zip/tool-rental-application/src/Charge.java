//class to set and retrieve the values for the charges of each tool

import java.time.LocalDate;

public class Charge {
    private Tool tool;
    private double Daily;
    private boolean Weekday;
    private boolean Weekend;
    private boolean Holiday;

    public Charge (Tool tool, double daily, boolean weekday, boolean weekend, boolean holiday){
        this.tool = tool;
        this.Daily = daily;
        this.Weekday = weekday;
        this.Weekend = weekend;
        this.Holiday = holiday;
    }

    public Tool getTool() {
        return tool;
    }

    public void setTool(Tool tool) {
        this.tool = tool;
    }

    public double getDaily() {
        return Daily;
    }

    public void setDaily(double daily) {
        Daily = daily;
    }

    public boolean isWeekday() {
        return Weekday;
    }

    public void setWeekday(boolean weekday) {
        Weekday = weekday;
    }

    public boolean isWeekend() {
        return Weekend;
    }

    public void setWeekend(boolean weekend) {
        Weekend = weekend;
    }

    public boolean isHoliday() {
        return Holiday;
    }

    public void setHoliday(boolean holiday) {
        Holiday = holiday;
    }

//    public void checkout(String code, int rentalCount, double discount, LocalDate checkoutDate){
//        Tool tool = new Tool();
//
//
//    }


}
