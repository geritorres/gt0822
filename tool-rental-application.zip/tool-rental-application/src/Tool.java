//tool class that sets and retrieves the properties for each tool in the document

public class Tool {
    private String Code;
    private String Type;
    private String Brand;

    private Charge charge;

    public Tool (String code, String type, String brand){
        this.Code = code;
        this.Type = type;
        this.Brand = brand;
    }

    public void setCode(String code) {
        Code = code;
    }

    public void setType(String type) {
        Type = type;
    }

    public void setBrand(String brand) {
        Brand = brand;
    }

    public String getCode() {
        return Code;
    }

    public String getType() {
        return Type;
    }

    public String getBrand() {
        return Brand;
    }
}
